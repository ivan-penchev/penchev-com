﻿namespace CarRentalSystem.Domain.Common
{
    public interface IAggregateRoot
    {
    }
}
